<div class="container-fluid">
    <div class="row">
        <div class="footer">
            <p>Copyright © <?php echo date("Y"); ?> Designed by <a href='https://adminsit.in/' target="_blank">Admins
                    Affordable Computers</a>. All rights reserved.</p>
        </div>
    </div>
</div>